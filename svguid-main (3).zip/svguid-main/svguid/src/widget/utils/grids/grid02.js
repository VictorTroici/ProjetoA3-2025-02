
export default [
    //Canto superior esquerdo
    { x: 0, y: 0, width: 500, height: 500 },
    //Canto inferior direito
    { x: 500, y: 500, width: 500, height: 500 },

    { x: 500, y: 0, width: 250, height: 250 },
    { x: 750, y: 0, width: 250, height: 250 },
    { x: 500, y: 250, width: 250, height: 250 },
    { x: 750, y: 250, width: 250, height: 250 },

    { x: 0, y: 500, width: 250, height: 250 },
    { x: 250, y: 500, width: 250, height: 250 },
    { x: 0, y: 750, width: 250, height: 250 },
    { x: 250, y: 750, width: 250, height: 250 },
]
